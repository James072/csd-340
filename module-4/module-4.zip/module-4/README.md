# csd-340
<DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
	<h1>CSD-340 Web Development with HTML and CSS</h1>
	<h2>Contributors:</h2>
	<ul>
		<li>Prof. Sue Sampson</li>
		<li>James Brown</li>
	</ul>
</body>
</html>

Repo for Web Development class
